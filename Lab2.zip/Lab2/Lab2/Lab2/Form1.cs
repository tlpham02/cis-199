﻿// W8449
// 2
// February 4, 2018
// 01
// This program is used to calculate tip amounts within the 15%, 18%, and 20% of the entire bill.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Calculate_Click(object sender, EventArgs e)
        {
            double mealPrice; // meal price variable
            double tipLow; // 15% of tip amount
            double tipMed; // 18% of tip amount
            double tipHigh; // 20% of tip amount

            mealPrice = double.Parse(mealPriceAmount.Text); // State meal price variable

            // Tip Rates Amount
            tipLow = mealPrice * .15;
            tipMed = mealPrice * .18;
            tipHigh = mealPrice * .20;

            // Tip Rates Output
            fifteen.Text = tipLow.ToString("C");
            eighteen.Text = tipMed.ToString("C");
            twenty.Text = tipHigh.ToString("C");


        }
    }
}
