﻿namespace Lab2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.food = new System.Windows.Forms.Label();
            this.Low = new System.Windows.Forms.Label();
            this.Med = new System.Windows.Forms.Label();
            this.High = new System.Windows.Forms.Label();
            this.mealPriceAmount = new System.Windows.Forms.TextBox();
            this.fifteen = new System.Windows.Forms.Label();
            this.eighteen = new System.Windows.Forms.Label();
            this.twenty = new System.Windows.Forms.Label();
            this.Calculate = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // food
            // 
            this.food.AutoSize = true;
            this.food.Location = new System.Drawing.Point(29, 22);
            this.food.Name = "food";
            this.food.Size = new System.Drawing.Size(98, 13);
            this.food.TabIndex = 0;
            this.food.Text = "Enter price of meal:";
            // 
            // Low
            // 
            this.Low.AutoSize = true;
            this.Low.Location = new System.Drawing.Point(92, 68);
            this.Low.Name = "Low";
            this.Low.Size = new System.Drawing.Size(30, 13);
            this.Low.TabIndex = 1;
            this.Low.Text = "15 %";
            // 
            // Med
            // 
            this.Med.AutoSize = true;
            this.Med.Location = new System.Drawing.Point(92, 114);
            this.Med.Name = "Med";
            this.Med.Size = new System.Drawing.Size(30, 13);
            this.Med.TabIndex = 2;
            this.Med.Text = "18 %";
            // 
            // High
            // 
            this.High.AutoSize = true;
            this.High.Location = new System.Drawing.Point(92, 158);
            this.High.Name = "High";
            this.High.Size = new System.Drawing.Size(30, 13);
            this.High.TabIndex = 3;
            this.High.Text = "20 %";
            // 
            // mealPriceAmount
            // 
            this.mealPriceAmount.Location = new System.Drawing.Point(133, 19);
            this.mealPriceAmount.Name = "mealPriceAmount";
            this.mealPriceAmount.Size = new System.Drawing.Size(100, 20);
            this.mealPriceAmount.TabIndex = 4;
            // 
            // fifteen
            // 
            this.fifteen.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fifteen.Location = new System.Drawing.Point(133, 67);
            this.fifteen.Name = "fifteen";
            this.fifteen.Size = new System.Drawing.Size(100, 23);
            this.fifteen.TabIndex = 5;
            // 
            // eighteen
            // 
            this.eighteen.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.eighteen.Location = new System.Drawing.Point(133, 113);
            this.eighteen.Name = "eighteen";
            this.eighteen.Size = new System.Drawing.Size(100, 23);
            this.eighteen.TabIndex = 6;
            // 
            // twenty
            // 
            this.twenty.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.twenty.Location = new System.Drawing.Point(133, 157);
            this.twenty.Name = "twenty";
            this.twenty.Size = new System.Drawing.Size(100, 23);
            this.twenty.TabIndex = 7;
            // 
            // Calculate
            // 
            this.Calculate.Location = new System.Drawing.Point(85, 221);
            this.Calculate.Name = "Calculate";
            this.Calculate.Size = new System.Drawing.Size(127, 31);
            this.Calculate.TabIndex = 8;
            this.Calculate.Text = "Calculate Tip";
            this.Calculate.UseVisualStyleBackColor = true;
            this.Calculate.Click += new System.EventHandler(this.Calculate_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(292, 273);
            this.Controls.Add(this.Calculate);
            this.Controls.Add(this.twenty);
            this.Controls.Add(this.eighteen);
            this.Controls.Add(this.fifteen);
            this.Controls.Add(this.mealPriceAmount);
            this.Controls.Add(this.High);
            this.Controls.Add(this.Med);
            this.Controls.Add(this.Low);
            this.Controls.Add(this.food);
            this.Name = "Form1";
            this.Text = "Lab 2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label food;
        private System.Windows.Forms.Label Low;
        private System.Windows.Forms.Label Med;
        private System.Windows.Forms.Label High;
        private System.Windows.Forms.TextBox mealPriceAmount;
        private System.Windows.Forms.Label fifteen;
        private System.Windows.Forms.Label eighteen;
        private System.Windows.Forms.Label twenty;
        private System.Windows.Forms.Button Calculate;
    }
}

