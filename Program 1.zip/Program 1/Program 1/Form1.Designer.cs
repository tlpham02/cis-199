﻿namespace Program_1
{
    partial class Program1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Introduction = new System.Windows.Forms.Label();
            this.length = new System.Windows.Forms.Label();
            this.height = new System.Windows.Forms.Label();
            this.doors = new System.Windows.Forms.Label();
            this.windows = new System.Windows.Forms.Label();
            this.paint = new System.Windows.Forms.Label();
            this.gallons = new System.Windows.Forms.Label();
            this.wallLength = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.wallHeight = new System.Windows.Forms.TextBox();
            this.gallonPaint = new System.Windows.Forms.TextBox();
            this.coatPaint = new System.Windows.Forms.TextBox();
            this.windowCount = new System.Windows.Forms.TextBox();
            this.doorCount = new System.Windows.Forms.TextBox();
            this.Calculation = new System.Windows.Forms.Button();
            this.minGallon = new System.Windows.Forms.Label();
            this.needGallons = new System.Windows.Forms.Label();
            this.cost = new System.Windows.Forms.Label();
            this.minPaint = new System.Windows.Forms.Label();
            this.gallonsNeeded = new System.Windows.Forms.Label();
            this.totalCost = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Introduction
            // 
            this.Introduction.AutoSize = true;
            this.Introduction.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Introduction.Location = new System.Drawing.Point(42, 20);
            this.Introduction.Name = "Introduction";
            this.Introduction.Size = new System.Drawing.Size(307, 17);
            this.Introduction.TabIndex = 0;
            this.Introduction.Text = "Welcome to the Handy-Dandy Paint Estimator";
            this.Introduction.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // length
            // 
            this.length.AutoSize = true;
            this.length.Location = new System.Drawing.Point(12, 66);
            this.length.Name = "length";
            this.length.Size = new System.Drawing.Size(197, 13);
            this.length.TabIndex = 1;
            this.length.Text = "Enter the total length of all walls (in feet):";
            // 
            // height
            // 
            this.height.AutoSize = true;
            this.height.Location = new System.Drawing.Point(12, 99);
            this.height.Name = "height";
            this.height.Size = new System.Drawing.Size(179, 13);
            this.height.TabIndex = 2;
            this.height.Text = "Enter the height of the walls (in feet):";
            // 
            // doors
            // 
            this.doors.AutoSize = true;
            this.doors.Location = new System.Drawing.Point(12, 132);
            this.doors.Name = "doors";
            this.doors.Size = new System.Drawing.Size(194, 13);
            this.doors.TabIndex = 3;
            this.doors.Text = "Enter the number of doors (non-neg int):";
            // 
            // windows
            // 
            this.windows.AutoSize = true;
            this.windows.Location = new System.Drawing.Point(12, 169);
            this.windows.Name = "windows";
            this.windows.Size = new System.Drawing.Size(209, 13);
            this.windows.TabIndex = 4;
            this.windows.Text = "Enter the number of windows (non-neg int):";
            // 
            // paint
            // 
            this.paint.AutoSize = true;
            this.paint.Location = new System.Drawing.Point(12, 203);
            this.paint.Name = "paint";
            this.paint.Size = new System.Drawing.Size(232, 13);
            this.paint.TabIndex = 5;
            this.paint.Text = "Enter the number of coats of paint (non-neg int):";
            // 
            // gallons
            // 
            this.gallons.AutoSize = true;
            this.gallons.Location = new System.Drawing.Point(12, 238);
            this.gallons.Name = "gallons";
            this.gallons.Size = new System.Drawing.Size(189, 13);
            this.gallons.TabIndex = 6;
            this.gallons.Text = "Enter the cost per gallon of paint (in $):";
            // 
            // wallLength
            // 
            this.wallLength.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.wallLength.Location = new System.Drawing.Point(261, 59);
            this.wallLength.Name = "wallLength";
            this.wallLength.Size = new System.Drawing.Size(100, 20);
            this.wallLength.TabIndex = 7;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(215, 91);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(0, 20);
            this.textBox2.TabIndex = 8;
            // 
            // wallHeight
            // 
            this.wallHeight.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.wallHeight.Location = new System.Drawing.Point(261, 92);
            this.wallHeight.Name = "wallHeight";
            this.wallHeight.Size = new System.Drawing.Size(100, 20);
            this.wallHeight.TabIndex = 9;
            // 
            // gallonPaint
            // 
            this.gallonPaint.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.gallonPaint.Location = new System.Drawing.Point(261, 236);
            this.gallonPaint.Name = "gallonPaint";
            this.gallonPaint.Size = new System.Drawing.Size(100, 20);
            this.gallonPaint.TabIndex = 10;
            // 
            // coatPaint
            // 
            this.coatPaint.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.coatPaint.Location = new System.Drawing.Point(261, 201);
            this.coatPaint.Name = "coatPaint";
            this.coatPaint.Size = new System.Drawing.Size(100, 20);
            this.coatPaint.TabIndex = 11;
            // 
            // windowCount
            // 
            this.windowCount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.windowCount.Location = new System.Drawing.Point(261, 167);
            this.windowCount.Name = "windowCount";
            this.windowCount.Size = new System.Drawing.Size(100, 20);
            this.windowCount.TabIndex = 12;
            // 
            // doorCount
            // 
            this.doorCount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.doorCount.Location = new System.Drawing.Point(261, 130);
            this.doorCount.Name = "doorCount";
            this.doorCount.Size = new System.Drawing.Size(100, 20);
            this.doorCount.TabIndex = 13;
            // 
            // Calculation
            // 
            this.Calculation.Location = new System.Drawing.Point(159, 474);
            this.Calculation.Name = "Calculation";
            this.Calculation.Size = new System.Drawing.Size(75, 23);
            this.Calculation.TabIndex = 14;
            this.Calculation.Text = "Calculate!";
            this.Calculation.UseVisualStyleBackColor = true;
            this.Calculation.Click += new System.EventHandler(this.Calculation_Click);
            // 
            // minGallon
            // 
            this.minGallon.AutoSize = true;
            this.minGallon.Location = new System.Drawing.Point(30, 345);
            this.minGallon.Name = "minGallon";
            this.minGallon.Size = new System.Drawing.Size(164, 13);
            this.minGallon.TabIndex = 15;
            this.minGallon.Text = "Minimum gallons of paint needed:";
            // 
            // needGallons
            // 
            this.needGallons.AutoSize = true;
            this.needGallons.Location = new System.Drawing.Point(108, 389);
            this.needGallons.Name = "needGallons";
            this.needGallons.Size = new System.Drawing.Size(86, 13);
            this.needGallons.TabIndex = 16;
            this.needGallons.Text = "Gallons Needed:";
            // 
            // cost
            // 
            this.cost.AutoSize = true;
            this.cost.Location = new System.Drawing.Point(133, 430);
            this.cost.Name = "cost";
            this.cost.Size = new System.Drawing.Size(58, 13);
            this.cost.TabIndex = 17;
            this.cost.Text = "Total Cost:";
            // 
            // minPaint
            // 
            this.minPaint.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.minPaint.Location = new System.Drawing.Point(212, 345);
            this.minPaint.Name = "minPaint";
            this.minPaint.Size = new System.Drawing.Size(100, 23);
            this.minPaint.TabIndex = 18;
            // 
            // gallonsNeeded
            // 
            this.gallonsNeeded.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.gallonsNeeded.Location = new System.Drawing.Point(212, 389);
            this.gallonsNeeded.Name = "gallonsNeeded";
            this.gallonsNeeded.Size = new System.Drawing.Size(100, 23);
            this.gallonsNeeded.TabIndex = 19;
            // 
            // totalCost
            // 
            this.totalCost.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalCost.Location = new System.Drawing.Point(212, 430);
            this.totalCost.Name = "totalCost";
            this.totalCost.Size = new System.Drawing.Size(100, 23);
            this.totalCost.TabIndex = 20;
            // 
            // Program1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(392, 523);
            this.Controls.Add(this.totalCost);
            this.Controls.Add(this.gallonsNeeded);
            this.Controls.Add(this.minPaint);
            this.Controls.Add(this.cost);
            this.Controls.Add(this.needGallons);
            this.Controls.Add(this.minGallon);
            this.Controls.Add(this.Calculation);
            this.Controls.Add(this.doorCount);
            this.Controls.Add(this.windowCount);
            this.Controls.Add(this.coatPaint);
            this.Controls.Add(this.gallonPaint);
            this.Controls.Add(this.wallHeight);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.wallLength);
            this.Controls.Add(this.gallons);
            this.Controls.Add(this.paint);
            this.Controls.Add(this.windows);
            this.Controls.Add(this.doors);
            this.Controls.Add(this.height);
            this.Controls.Add(this.length);
            this.Controls.Add(this.Introduction);
            this.Name = "Program1";
            this.Text = "Program1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Introduction;
        private System.Windows.Forms.Label length;
        private System.Windows.Forms.Label height;
        private System.Windows.Forms.Label doors;
        private System.Windows.Forms.Label windows;
        private System.Windows.Forms.Label paint;
        private System.Windows.Forms.Label gallons;
        private System.Windows.Forms.TextBox wallLength;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox wallHeight;
        private System.Windows.Forms.TextBox gallonPaint;
        private System.Windows.Forms.TextBox coatPaint;
        private System.Windows.Forms.TextBox windowCount;
        private System.Windows.Forms.TextBox doorCount;
        private System.Windows.Forms.Button Calculation;
        private System.Windows.Forms.Label minGallon;
        private System.Windows.Forms.Label needGallons;
        private System.Windows.Forms.Label cost;
        private System.Windows.Forms.Label minPaint;
        private System.Windows.Forms.Label gallonsNeeded;
        private System.Windows.Forms.Label totalCost;
    }
}

