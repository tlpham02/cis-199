﻿//W8449
//Program 2
//March 8, 2018
//CIS199-01
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program_2
{
    public partial class Program2 : Form
    {
        public Program2()
        {
            InitializeComponent();
        }

        private void checkButton_Click(object sender, EventArgs e)
        {
            double creditHour;
            char lastInitial;
            string dateOfRegistration;
            string timeOfRegistration;
            const int SENIOR_CREDITS = 90;
            const int JUNIOR_CREDITS = 60;
            const int SOPHOMORE_CREDITS = 30;


            if(double.TryParse(creditHourInput.Text, out creditHour))
            {
                creditHour = Convert.ToDouble(creditHourInput.Text);
            }
            else
            {
                MessageBox.Show("Please enter a valid number of credit hours");
            }
            if(char.TryParse(creditHourInput.Text, out lastInitial) == false)
            {
                lastInitial = Convert.ToChar(lastInitialInput.Text);
            }
            else
            {
                MessageBox.Show("Please enter a valid last initial");
            }
            lastInitial = Char.ToUpper(lastInitial);

            if(creditHour >= SENIOR_CREDITS)
            {
                dateOfRegistration = "March 28, 2018";
                dateOutput.Text = dateOfRegistration;
            }
            else if(creditHour >= JUNIOR_CREDITS)
            {
                dateOfRegistration = "March 29, 2018";
                dateOutput.Text = dateOfRegistration;
            }
            else if(creditHour >= SOPHOMORE_CREDITS && lastInitial.CompareTo('L') <= 0)
            {
                dateOfRegistration = "March 30, 2018";
                dateOutput.Text = dateOfRegistration;
            }
            else if(creditHour >= SOPHOMORE_CREDITS && lastInitial.CompareTo('L') > 0)
            {
                dateOfRegistration = "April 2, 2018";
                dateOutput.Text = dateOfRegistration;
            }
            else if(creditHour < SOPHOMORE_CREDITS && lastInitial.CompareTo('L') <= 0)
            {
                dateOfRegistration = "April 3, 2018";
                dateOutput.Text = dateOfRegistration;
            }
            else if(creditHour < SOPHOMORE_CREDITS && lastInitial.CompareTo('L') > 0)
            {
                dateOfRegistration = "April 4, 2018";
                dateOutput.Text = dateOfRegistration;
            }

            if (creditHour >= SENIOR_CREDITS)
            {
                if(lastInitial.CompareTo('T') >= 0)
                {
                    timeOfRegistration = "4PM";
                    timeOutput.Text = timeOfRegistration;
                }
                else if(lastInitial.CompareTo('P') >= 0)
                {
                    timeOfRegistration = "2PM";
                    timeOutput.Text = timeOfRegistration;
                }
                else if(lastInitial.CompareTo('J') >= 0)
                {
                    timeOfRegistration = "11:30AM";
                    timeOutput.Text = timeOfRegistration;
                }
                else if(lastInitial.CompareTo('E') >= 0)
                {
                    timeOfRegistration = "10AM";
                    timeOutput.Text = timeOfRegistration;
                }
                else if(lastInitial.CompareTo('A') >= 0)
                {
                    timeOfRegistration = "8:30AM";
                    timeOutput.Text = timeOfRegistration;
                }
            }
            if(creditHour >= JUNIOR_CREDITS)
            {
                if(lastInitial.CompareTo('T') >= 0)
                {
                    timeOfRegistration = "4PM";
                    timeOutput.Text = timeOfRegistration;
                }
                else if(lastInitial.CompareTo('P') >= 0)
                {
                    timeOfRegistration = "2PM";
                    timeOutput.Text = timeOfRegistration;
                }
                else if(lastInitial.CompareTo('J') >= 0)
                {
                    timeOfRegistration = "11:30AM";
                    timeOutput.Text = timeOfRegistration;
                }
                else if(lastInitial.CompareTo('E') >= 0)
                {
                    timeOfRegistration = "10AM";
                    timeOutput.Text = timeOfRegistration;
                }
                else if(lastInitial.CompareTo('A') >= 0)
                {
                    timeOfRegistration = "8:30AM";
                    timeOutput.Text = timeOfRegistration;
                }
            }

            if(creditHour >= SOPHOMORE_CREDITS && lastInitial.CompareTo('L') <= 0)
            {
                if(lastInitial.CompareTo('J') >= 0)
                {
                    timeOfRegistration = "4PM";
                    timeOutput.Text = timeOfRegistration;
                }
                else if (lastInitial.CompareTo('G') >= 0)
                {
                    timeOfRegistration = "2PM";
                    timeOutput.Text = timeOfRegistration;
                }
                else if(lastInitial.CompareTo('E') >= 0)
                {
                    timeOfRegistration = "11:30AM";
                    timeOutput.Text = timeOfRegistration;
                }
                else if(lastInitial.CompareTo('C') >= 0)
                {
                    timeOfRegistration = "10AM";
                    timeOutput.Text = timeOfRegistration;
                }
                else if(lastInitial.CompareTo('A') >= 0)
                {
                    timeOfRegistration = "8:30AM";
                    timeOutput.Text = timeOfRegistration;
                }
            }
            if(creditHour >= SOPHOMORE_CREDITS && lastInitial.CompareTo('L') > 0)
            {
                if(lastInitial.CompareTo('W') >= 0)
                {
                    timeOfRegistration = "4PM";
                    timeOutput.Text = timeOfRegistration;
                }
                else if(lastInitial.CompareTo('T') >= 0)
                {
                    timeOfRegistration = "2PM";
                    timeOutput.Text = timeOfRegistration;
                }
                else if(lastInitial.CompareTo('R') >= 0)
                {
                    timeOfRegistration = "11:30AM";
                    timeOutput.Text = timeOfRegistration;
                }
                else if(lastInitial.CompareTo('P') >= 0)
                {
                    timeOfRegistration = "10AM";
                    timeOutput.Text = timeOfRegistration;
                }
                else if(lastInitial.CompareTo('M') >= 0)
                {
                    timeOfRegistration = "8AM";
                    timeOutput.Text = timeOfRegistration;
                }
            }
            if(creditHour < SOPHOMORE_CREDITS && lastInitial.CompareTo('L') <= 0)
            {
                if(lastInitial.CompareTo('J') >= 0)
                {
                    timeOfRegistration = "4PM";
                    timeOutput.Text = timeOfRegistration;
                }
                else if(lastInitial.CompareTo('G') >= 0)
                {
                    timeOfRegistration = "2PM";
                    timeOutput.Text = timeOfRegistration;
                }
                else if(lastInitial.CompareTo('E') >= 0)
                {
                    timeOfRegistration = "11:30AM";
                    timeOutput.Text = timeOfRegistration;
                }
                else if(lastInitial.CompareTo('C') >= 0)
                {
                    timeOfRegistration = "10AM";
                    timeOutput.Text = timeOfRegistration;
                }
                else if(lastInitial.CompareTo('A') >= 0)
                {
                    timeOfRegistration = "8:30AM";
                    timeOutput.Text = timeOfRegistration;
                }
            }
            if(creditHour < SOPHOMORE_CREDITS && lastInitial.CompareTo('L') > 0)
            {
                if(lastInitial.CompareTo('W') >= 0)
                {
                    timeOfRegistration = "4PM";
                    timeOutput.Text = timeOfRegistration;
                }
                else if(lastInitial.CompareTo('T') >= 0)
                {
                    timeOfRegistration = "2PM";
                    timeOutput.Text = timeOfRegistration;
                }
                else if(lastInitial.CompareTo('R') >= 0)
                {
                    timeOfRegistration = "11:30AM";
                    timeOutput.Text = timeOfRegistration;
                }
                else if(lastInitial.CompareTo('P') >= 0)
                {
                    timeOfRegistration = "10AM";
                    timeOutput.Text = timeOfRegistration;
                }
                else if(lastInitial.CompareTo('M') >= 0)
                {
                    timeOfRegistration = "8:30AM";
                    timeOutput.Text = timeOfRegistration;
                }
            }
        }
    }
}
