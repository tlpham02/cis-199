﻿namespace Lab3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.sphereRadius = new System.Windows.Forms.Label();
            this.sphere1 = new System.Windows.Forms.PictureBox();
            this.radiusSphere = new System.Windows.Forms.TextBox();
            this.sphereDiameter = new System.Windows.Forms.Label();
            this.sphereSurfaceArea = new System.Windows.Forms.Label();
            this.sphereVolume = new System.Windows.Forms.Label();
            this.diameterRate = new System.Windows.Forms.Label();
            this.surfaceAreaRate = new System.Windows.Forms.Label();
            this.volumeRate = new System.Windows.Forms.Label();
            this.calculateRadius = new System.Windows.Forms.Button();
            this.sphere2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.sphere1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sphere2)).BeginInit();
            this.SuspendLayout();
            // 
            // sphereRadius
            // 
            this.sphereRadius.AutoSize = true;
            this.sphereRadius.Location = new System.Drawing.Point(166, 64);
            this.sphereRadius.Name = "sphereRadius";
            this.sphereRadius.Size = new System.Drawing.Size(93, 13);
            this.sphereRadius.TabIndex = 0;
            this.sphereRadius.Text = "Radius of sphere: ";
            // 
            // sphere1
            // 
            this.sphere1.Image = ((System.Drawing.Image)(resources.GetObject("sphere1.Image")));
            this.sphere1.Location = new System.Drawing.Point(12, 12);
            this.sphere1.Name = "sphere1";
            this.sphere1.Size = new System.Drawing.Size(150, 150);
            this.sphere1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.sphere1.TabIndex = 1;
            this.sphere1.TabStop = false;
            this.sphere1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // radiusSphere
            // 
            this.radiusSphere.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.radiusSphere.ForeColor = System.Drawing.Color.Black;
            this.radiusSphere.Location = new System.Drawing.Point(265, 61);
            this.radiusSphere.Name = "radiusSphere";
            this.radiusSphere.Size = new System.Drawing.Size(100, 20);
            this.radiusSphere.TabIndex = 2;
            this.radiusSphere.TextChanged += new System.EventHandler(this.Radius_TextChanged);
            // 
            // sphereDiameter
            // 
            this.sphereDiameter.AutoSize = true;
            this.sphereDiameter.Location = new System.Drawing.Point(32, 222);
            this.sphereDiameter.Name = "sphereDiameter";
            this.sphereDiameter.Size = new System.Drawing.Size(49, 13);
            this.sphereDiameter.TabIndex = 3;
            this.sphereDiameter.Text = "Diameter";
            // 
            // sphereSurfaceArea
            // 
            this.sphereSurfaceArea.AutoSize = true;
            this.sphereSurfaceArea.Location = new System.Drawing.Point(12, 265);
            this.sphereSurfaceArea.Name = "sphereSurfaceArea";
            this.sphereSurfaceArea.Size = new System.Drawing.Size(69, 13);
            this.sphereSurfaceArea.TabIndex = 4;
            this.sphereSurfaceArea.Text = "Surface Area";
            // 
            // sphereVolume
            // 
            this.sphereVolume.AutoSize = true;
            this.sphereVolume.Location = new System.Drawing.Point(39, 305);
            this.sphereVolume.Name = "sphereVolume";
            this.sphereVolume.Size = new System.Drawing.Size(42, 13);
            this.sphereVolume.TabIndex = 5;
            this.sphereVolume.Text = "Volume";
            // 
            // diameterRate
            // 
            this.diameterRate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.diameterRate.Location = new System.Drawing.Point(87, 221);
            this.diameterRate.Name = "diameterRate";
            this.diameterRate.Size = new System.Drawing.Size(92, 21);
            this.diameterRate.TabIndex = 6;
            this.diameterRate.Click += new System.EventHandler(this.label5_Click);
            // 
            // surfaceAreaRate
            // 
            this.surfaceAreaRate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.surfaceAreaRate.Location = new System.Drawing.Point(87, 264);
            this.surfaceAreaRate.Name = "surfaceAreaRate";
            this.surfaceAreaRate.Size = new System.Drawing.Size(92, 21);
            this.surfaceAreaRate.TabIndex = 7;
            // 
            // volumeRate
            // 
            this.volumeRate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.volumeRate.Location = new System.Drawing.Point(87, 304);
            this.volumeRate.Name = "volumeRate";
            this.volumeRate.Size = new System.Drawing.Size(92, 21);
            this.volumeRate.TabIndex = 8;
            // 
            // calculateRadius
            // 
            this.calculateRadius.Location = new System.Drawing.Point(276, 100);
            this.calculateRadius.Name = "calculateRadius";
            this.calculateRadius.Size = new System.Drawing.Size(75, 23);
            this.calculateRadius.TabIndex = 9;
            this.calculateRadius.Text = "Calculate";
            this.calculateRadius.UseVisualStyleBackColor = true;
            this.calculateRadius.Click += new System.EventHandler(this.calculateRadius_Click);
            // 
            // sphere2
            // 
            this.sphere2.Image = ((System.Drawing.Image)(resources.GetObject("sphere2.Image")));
            this.sphere2.Location = new System.Drawing.Point(230, 211);
            this.sphere2.Name = "sphere2";
            this.sphere2.Size = new System.Drawing.Size(150, 150);
            this.sphere2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.sphere2.TabIndex = 10;
            this.sphere2.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(392, 373);
            this.Controls.Add(this.sphere2);
            this.Controls.Add(this.calculateRadius);
            this.Controls.Add(this.volumeRate);
            this.Controls.Add(this.surfaceAreaRate);
            this.Controls.Add(this.diameterRate);
            this.Controls.Add(this.sphereVolume);
            this.Controls.Add(this.sphereSurfaceArea);
            this.Controls.Add(this.sphereDiameter);
            this.Controls.Add(this.radiusSphere);
            this.Controls.Add(this.sphere1);
            this.Controls.Add(this.sphereRadius);
            this.Name = "Form1";
            this.Text = "Lab 3";
            ((System.ComponentModel.ISupportInitialize)(this.sphere1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sphere2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label sphereRadius;
        private System.Windows.Forms.PictureBox sphere1;
        private System.Windows.Forms.TextBox radiusSphere;
        private System.Windows.Forms.Label sphereDiameter;
        private System.Windows.Forms.Label sphereSurfaceArea;
        private System.Windows.Forms.Label sphereVolume;
        private System.Windows.Forms.Label diameterRate;
        private System.Windows.Forms.Label surfaceAreaRate;
        private System.Windows.Forms.Label volumeRate;
        private System.Windows.Forms.Button calculateRadius;
        private System.Windows.Forms.PictureBox sphere2;
    }
}

