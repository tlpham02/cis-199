﻿namespace Lab4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.currentGPA = new System.Windows.Forms.Label();
            this.testScore = new System.Windows.Forms.Label();
            this.currentGPAInput = new System.Windows.Forms.TextBox();
            this.testScoreInput = new System.Windows.Forms.TextBox();
            this.runningTotal = new System.Windows.Forms.Label();
            this.acceptReject = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // currentGPA
            // 
            this.currentGPA.AutoSize = true;
            this.currentGPA.Location = new System.Drawing.Point(62, 99);
            this.currentGPA.Name = "currentGPA";
            this.currentGPA.Size = new System.Drawing.Size(121, 13);
            this.currentGPA.TabIndex = 0;
            this.currentGPA.Text = "Enter High School GPA:";
            // 
            // testScore
            // 
            this.testScore.AutoSize = true;
            this.testScore.Location = new System.Drawing.Point(43, 153);
            this.testScore.Name = "testScore";
            this.testScore.Size = new System.Drawing.Size(140, 13);
            this.testScore.TabIndex = 1;
            this.testScore.Text = "Enter Admission Test Score:";
            // 
            // currentGPAInput
            // 
            this.currentGPAInput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.currentGPAInput.Location = new System.Drawing.Point(219, 97);
            this.currentGPAInput.Name = "currentGPAInput";
            this.currentGPAInput.Size = new System.Drawing.Size(100, 20);
            this.currentGPAInput.TabIndex = 2;
            // 
            // testScoreInput
            // 
            this.testScoreInput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.testScoreInput.Location = new System.Drawing.Point(219, 150);
            this.testScoreInput.Name = "testScoreInput";
            this.testScoreInput.Size = new System.Drawing.Size(100, 20);
            this.testScoreInput.TabIndex = 3;
            // 
            // runningTotal
            // 
            this.runningTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.runningTotal.Location = new System.Drawing.Point(134, 277);
            this.runningTotal.Name = "runningTotal";
            this.runningTotal.Size = new System.Drawing.Size(121, 32);
            this.runningTotal.TabIndex = 4;
            // 
            // acceptReject
            // 
            this.acceptReject.Location = new System.Drawing.Point(157, 347);
            this.acceptReject.Name = "acceptReject";
            this.acceptReject.Size = new System.Drawing.Size(75, 23);
            this.acceptReject.TabIndex = 5;
            this.acceptReject.Text = "Check";
            this.acceptReject.UseVisualStyleBackColor = true;
            this.acceptReject.Click += new System.EventHandler(this.acceptReject_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 411);
            this.Controls.Add(this.acceptReject);
            this.Controls.Add(this.runningTotal);
            this.Controls.Add(this.testScoreInput);
            this.Controls.Add(this.currentGPAInput);
            this.Controls.Add(this.testScore);
            this.Controls.Add(this.currentGPA);
            this.Name = "Form1";
            this.Text = "Lab4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label currentGPA;
        private System.Windows.Forms.Label testScore;
        private System.Windows.Forms.TextBox currentGPAInput;
        private System.Windows.Forms.TextBox testScoreInput;
        private System.Windows.Forms.Label runningTotal;
        private System.Windows.Forms.Button acceptReject;
    }
}

