﻿//W8449
//Lab 5
//March 4, 2018
//01
//This lab expresses the use of nested loops in a Console application using stars as a reference.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_5
{
    class Program
    {
        static void Main(string[] args)
        {
            int MAX_ROWS; // Declaring the variable

            Console.Write("Pattern A");
            Console.WriteLine();
            Console.WriteLine();

            MAX_ROWS = 10; // Initiating varible/logic for Pattern A


            for (int i = 1; i <= MAX_ROWS; i++)
            {
                for (int j = 1; j <= i; j++)
                {
                    Console.Write("*");
                }   
                Console.WriteLine();
            }

            // Pattern B

            Console.Write("Pattern B");
            Console.WriteLine();
            Console.WriteLine();

            for (int i = MAX_ROWS; i > 0; i--)
            {
                for (int j = 1; j <= i; j++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }

            // Pattern C

            Console.Write("Pattern C");
            Console.WriteLine();
            Console.WriteLine();
            for (int i = MAX_ROWS; i > 0; i--)
            {
                for (int j = 1; j <= MAX_ROWS - i; j++)
                {
                    Console.Write(" ");
                }
                for (int k = 1; k <= i; k++)
                {
                    Console.Write("*");
                }
                Console.WriteLine("");
            }

            // Pattern D

            Console.Write("Pattern D");
            Console.WriteLine();
            Console.WriteLine();
            for (int i = 1; i <= MAX_ROWS; i++)
            {
                for (int j = 1; j <= MAX_ROWS - i; j++)
                {
                    Console.Write(" ");
                }
                for (int k = 1; k <= i; k++)
                {
                    Console.Write("*");
                }
                Console.WriteLine("");
            }
        }

    }
}
