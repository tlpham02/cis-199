﻿// Grading ID: W8449 
// Lab Number: 1
// Due Date: January 28, 2018
// Course Section: 01
// Brief Description: The purpose of this program is to perform many different calculations using the two inputs provided. These different operations are multiplication, division, addition, subtraction, and finding the mean.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1
{
    class Program
    {
        static void Main(string[] args)
        {
            double number1; // first floating point number
            double number2; // second floating point number
            double sum; // variable for sum
            double subtract; // variable for subtract
            double product; // variable for product
            double quotient; // variable for quotient
            double mean; // variable for mean

            Console.Write("Enter 1st floating point number: "); // Entering the first floating point number
            number1 = double.Parse(Console.ReadLine());
            Console.Write("Enter 2nd floating point number: "); // Entering the second floating point number
           number2 = double.Parse(Console.ReadLine());
            Console.WriteLine();

            sum = number1 + number2;

            Console.WriteLine(number1 + " + " + number2 + " = " + sum);

            subtract = number1 - number2;

            Console.WriteLine(number1 + " - " + number2 + " = " + subtract);

            product = number1 * number2;

            Console.WriteLine(number1 + " * " + number2 + " = " + product);

            quotient = number1 / number2;

            Console.WriteLine(number1 + " / " + number2 + " = " + quotient);

            mean = sum / 2;

            Console.WriteLine(number1 + " , " + number2 + " = " + mean);
        }
    }
}
