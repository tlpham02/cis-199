﻿// W8842
// Lab6
// March 25, 2018
// CIS 199-01
// The purpose of this lab is to have the student receive the given grade by using the number of words the student has typed. This lab explores the use of parallel arrays and range matching.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void checkGrade_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(wordInput.Text)) // Validating if the textbox has the correct digit or if it's empty

            {
                string gradeEarned = "";
                int num = Convert.ToInt32(wordInput.Text);

                if (num >= 0 && num <= 15) // Checking the numbers in between 0 and 15
                    gradeEarned = "F";
                else
                    if (num >= 16 && num <= 30) // Checking the numbers in between 16 and 30
                    gradeEarned = "D";
                else
                    if (num >= 31 && num <= 50) // Checking the numbers in between 31 and 50
                    gradeEarned = "C";
                else
                    if (num >= 51 && num <= 75) // Checking the numbers in between 51 and 75
                    gradeEarned = "B";
                else
                    if (num >= 76) // Checking the numbers greater than 75
                    gradeEarned = "A";
                else
                {
                    MessageBox.Show("You have entered an invalid entry", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error); // Warning pop-up
                }

                gradeOutput.Text = gradeEarned;
            }
            else
                MessageBox.Show("Enter the number of words typed", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error); // If the textbox is empty, this error message will show.
                    
        }
    }
}
